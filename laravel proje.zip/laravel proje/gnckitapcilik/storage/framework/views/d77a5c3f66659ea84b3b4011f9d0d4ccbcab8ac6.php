

<?php $__env->startSection('content2'); ?>
    <!-- Begin Page Content -->
    <div class="container">
        <br>
        <h2 class="mr-auto">Ürünler</h2>
        <div class="row">
            <div class="col d-flex justify-content-end">
                <a href="<?php echo e(route('urun.create')); ?>" class="btn btn-primary">Ürün Ekle</a>
            </div>
        </div>

        <br>

        <div class="card">
            <div class="card-body">
                <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Ürün Adı</th>
                            <th scope="col">Ürün Detay</th>
                            <th scope="col">Fiyat</th>
                            <th scope="col">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $urunler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $urun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($urun->urunad); ?></td>
                                <td><?php echo e($urun->urundetay); ?></td>
                                <td><?php echo e($urun->urunfiyat); ?></td>
                                <td class="d-flex">
                                    <a class="btn btn-info"
                                        href="<?php echo e(route('urun.edit', ['urun' => $urun->id])); ?>">Düzenle</a>
                                    <form method="Post" action="<?php echo e(route('urun.destroy', ['urun' => $urun->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger">Sil</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <?php echo e($urunler->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\gnckitapcilik\resources\views/urunler.blade.php ENDPATH**/ ?>