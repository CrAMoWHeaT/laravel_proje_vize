<?php $__env->startSection('content'); ?>
    
<section class="slider">
    <div id="carouselBookSlider" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="<?php echo e(asset('mytemplate/assets/images/slide1.png')); ?>" class="d-block w-100" alt="Online Schol" />
        </div>
        <div class="carousel-item">
          <img src="<?php echo e(asset('mytemplate/assets/images/slide2.png')); ?>" class="d-block w-100" alt="Dünya Çocuk Kitap Günü" />
        </div>
        <div class="carousel-item">
          <img src="<?php echo e(asset('mytemplate/assets/images/slide3.png')); ?>" class="d-block w-100" alt="Sevgililer Günü" />
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselBookSlider" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Önceki</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselBookSlider" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">sonraki</span>
      </button>
    </div>
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("app.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\gnckitapcilik\resources\views/index.blade.php ENDPATH**/ ?>