

<?php $__env->startSection('content'); ?>
    
<h1>Ürün Ekle</h1>

<form method="POST" action="<?php echo e(route('urun.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Ürün Adı</label>
      <input type="text" name="urunad" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Ürün Detay</label>
        <input type="text" name="urundetay" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Ürün Fiyat</label>
        <input type="text" name="urunfiyat" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
      </div>
    <button type="submit" class="btn btn-primary">Ürünü Ekle</button>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("app.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\izopanel\resources\views/create.blade.php ENDPATH**/ ?>