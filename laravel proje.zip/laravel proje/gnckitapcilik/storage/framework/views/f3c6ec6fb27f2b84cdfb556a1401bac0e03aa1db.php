

<?php $__env->startSection('content2'); ?>
    <h1>Giriş Yap</h1>

    <form method="POST" action="#">
        <?php echo csrf_field(); ?>

        <label for="email">E-posta:</label>
        <input type="email" name="email" required>

        <label for="password">Şifre:</label>
        <input type="password" name="password" required>

        <button type="submit">Giriş Yap</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\gnckitapcilik\resources\views/girisyap.blade.php ENDPATH**/ ?>