<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('index');
})->name("/");

Route::get('/login', function () {
    return view('girisyap');
});



Route::post('/register', 'RegisterController@create')->name('register');


Route::get('/urunler',"UrunController@index")->name("urunler");

Route::get("/urun","UrunController@create")->name("urun.create");
Route::post("/urun","UrunController@store")->name("urun.store");
Route::delete("/urun/{urun}","UrunController@destroy")->name("urun.destroy");
Route::get("/urun/{urun}","UrunController@edit")->name("urun.edit");
Route::put("/urun/{urun}","UrunController@update")->name("urun.update");
