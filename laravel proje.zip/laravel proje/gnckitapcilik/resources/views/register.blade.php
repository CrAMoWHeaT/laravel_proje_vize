@extends('app.adminlayout')

@section('content2')
    <h1>Kayıt Ol</h1>

    <form method="POST" action="{{route('register')}}">
        @csrf

        <label for="email">Ad Soyad:</label>
        <input type="text" name="name" required>

        <label for="email">E-posta:</label>
        <input type="email" name="email" required>

        <label for="password">Şifre:</label>
        <input type="password" name="password" required>

        <button type="submit" class="btn btn-success">Giriş Yap</button>
    </form>
@endsection
