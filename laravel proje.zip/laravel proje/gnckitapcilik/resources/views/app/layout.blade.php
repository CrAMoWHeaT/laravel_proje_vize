<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gnc Kitapçılık | Kitap Mağazası</title>
    <link rel="stylesheet" href="{{ asset('mytemplate/assets/bootstrap/css/bootstrap.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('mytemplate/assets/toastr/toastr.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('mytemplate/style.css') }}" />

</head>

<body>
    <nav class="navbar">
        <h2 class="title">Gnc Kitapçılık</h2>
        <ul class="menu">
            <script>
                var request = new XMLHttpRequest();
                request.open('GET', '{{ asset('mytemplate/navbar.json') }}', true);
                request.onreadystatechange = function() {
                    if (request.readyState === 4 && request.status === 200) {
                        var data = JSON.parse(request.responseText);

                        // <ul> elementini seçin
                        var ulElement = document.querySelector('.menu');

                        // Menü öğelerini döngü kullanarak <li> olarak ekleyin
                        data.menu.forEach(function(item) {
                            // <li> elementini oluşturun
                            var liElement = document.createElement('li');
                            liElement.textContent = item.name;

                            // Eğer "class" özelliği varsa, sınıfını ekleyin
                            if (item.class) {
                                liElement.className = item.class;
                            }

                            // <li> elementini <ul> elementine ekleyin
                            ulElement.appendChild(liElement);
                        });
                    }
                };
                request.send();
            </script>
        </ul>
        <ul class="menu__icons">
            <li><a style="padding: 6px; border-radius:3px; background-color:rgb(82, 172, 186);color:#000000;" href="{{route('urunler')}}"><i class="bi bi-person"></i></a></li>
            <li><i class="bi bi-search"></i></li>
            <li class="basket__icon" onclick="toggleModal()">
                <i class="bi bi-bag"></i>
                <span class="basket__count"></span>
            </li>
        </ul>
    </nav>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (Session::has('olumlu'))
        <div class="alert alert-success">
            {{ Session::get('olumlu') }}
        </div>
    @endif

    @yield('content')

    <section class="store my-5">
        <div class="filter__background"></div>
        <ul class="filter">
            <li class="active">Tümü</li>
            <li>ROMAN</li>
            <li>Kişisel Gelişim</li>
            <li>Fantastik</li>
        </ul>
        <div class="row book__list"></div>
    </section>
    <div class="basket__modal">
        <div class="basket__items">
            <i class="bi bi-x" onclick="toggleModal()"></i>
            <h2 class="basket__title">Senin Kitapların</h2>
            <ul class="basket__list">
                <li class="basket__item">Sepette ürününüz yok.</li>
            </ul>
            <div class="basket__total">
                <span class="fw-bold mb-3 fs-4 total__price"></span>
                <button class="btn__purple">Satın al</button>
            </div>
        </div>
    </div>

    <footer class="footer text-light py-4 bg-dark footer-dark">
        <div class="container">
            <div class="row">

                <div class="col-md-4">
                    Bursa/Yıldırım
                </div>
                <div class="col-md-4">Batuhan Genç <br><a href="mailto:batugenc1622@gmail.com">Bana ulaşmmak için buraya
                        tıklayabilirsiniz.</a></div>

                <div class="col-md-4">05467894512</div>
            </div>

        </div>
    </footer>

    <script type="text/javascript" src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('mytemplate/assets/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('mytemplate/assets/toastr/toastr.min.js') }}"></script>
    <script type="text/javascript">
        let bookList = [],
            basketList = [];

        toastr.options = {
            closeButton: false,
            debug: false,
            newestOnTop: false,
            progressBar: false,
            positionClass: "toast-bottom-right",
            preventDuplicates: false,
            onclick: null,
            showDuration: "300",
            hideDuration: "1000",
            timeOut: "5000",
            extendedTimeOut: "1000",
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut",
        };

        const toggleModal = () => {
            const basketModalEl = document.querySelector(".basket__modal");
            basketModalEl.classList.toggle("active");
        };

        const getBooks = () => {
            fetch("{{ asset('mytemplate/products.json') }}")
                .then((res) => res.json())
                .then((books) => (bookList = books));
        };

        getBooks();

        const createBookStars = (starRate) => {
            let starRateHtml = "";
            for (let i = 1; i <= 5; i++) {
                if (Math.round(starRate) >= i)
                    starRateHtml += `<i class="bi bi-star-fill active"></i>`;
                else starRateHtml += `<i class="bi bi-star-fill"></i>`;
            }

            return starRateHtml;
        };

        const createBookItemsHtml = () => {
            const bookListEl = document.querySelector(".book__list");
            let bookListHtml = "";
            bookList.forEach((book, index) => {
                bookListHtml += `<div class="col-5 ${index % 2 == 0 && "offset-2"} my-5">
    <div class="row book__card">
      <div class="col-6">
        <img
          class="img-fluid shadow"
          src="${book.imgSource}"
          width="258"
          height="400"
        />
      </div>
      <div class="col-6 d-flex flex-column justify-content-between">
        <div class="book__detail">
          <span class="fos gray fs-5">${book.author}</span><br />
          <span class="fs-4 fw-bold">${book.name}</span><br />
          <span class="book__star-rate">
            ${createBookStars(book.starRate)}
            <span class="gray">${book.reviewCount} reviews</span>
          </span>
        </div>
        <p class="book__description fos gray">
          ${book.description}
        </p>
        <div>
          <span class="black fw-bold fs-4 me-2">${book.price}₺</span>
          ${
            book.oldPrice
              ? `<span class="fs-4 fw-bold old__price">${book.oldPrice}</span>`
              : ""
          }
        </div>
        <button class="btn__purple" onclick="addBookToBasket(${
          book.id
        })">Sepete Ekle</button>
      </div>
    </div>
  </div>`;
            });

            bookListEl.innerHTML = bookListHtml;
        };

        const BOOK_TYPES = {
            ALL: "Tümü",
            NOVEL: "Roman",
            CHILDREN: "Çocuk",
            SELFIMPROVEMENT: "Kişisel Gelişim",
            HISTORY: "Tarih",
            FINANCE: "Finans",
            SCIENCE: "Bilim",
        };

        const createBookTypesHtml = () => {
            const filterEl = document.querySelector(".filter");
            let filterHtml = "";
            let filterTypes = ["ALL"];
            bookList.forEach((book) => {
                if (filterTypes.findIndex((filter) => filter == book.type) == -1)
                    filterTypes.push(book.type);
            });

            filterTypes.forEach((type, index) => {
                filterHtml += `<li class="${
      index == 0 ? "active" : null
    }" onclick="filterBooks(this)" data-type="${type}">${
      BOOK_TYPES[type] || type
    }</li>`;
            });

            filterEl.innerHTML = filterHtml;
        };

        const filterBooks = (filterEl) => {
            document.querySelector(".filter .active").classList.remove("active");
            filterEl.classList.add("active");
            let bookType = filterEl.dataset.type;
            getBooks();
            if (bookType != "ALL")
                bookList = bookList.filter((book) => book.type == bookType);
            createBookItemsHtml();
        };
        const listBasketItems = () => {
            localStorage.setItem("basketList", JSON.stringify(basketList));
            const basketListEl = document.querySelector(".basket__list");
            const basketCountEl = document.querySelector(".basket__count");
            basketCountEl.innerHTML = basketList.length > 0 ? basketList.length : null;
            const totalPriceEl = document.querySelector(".total__price");

            let basketListHtml = "";
            let totalPrice = 0;
            basketList.forEach((item) => {
                totalPrice += item.product.price * item.quantity;
                basketListHtml += `<li class="basket__item">
                <img
                src="${item.product.imgSource}"
                width="100"
                height="100"
                />
                <div class="basket__item-info">
                <h3 class="book__name">${item.product.name}</h3>
                <span class="book__price">${item.product.price}₺</span><br />
                <span class="book__remove" onclick="removeItemToBasket(${item.product.id})">Hepsini Sil</span>
                </div>
                <div class="book__count">
                <span class="decrease" onclick="decreaseItemToBasket(${item.product.id})">-</span>
                <span class="my-5">${item.quantity}</span>
                <span class="increase" onclick="increaseItemToBasket(${item.product.id})">+</span>
                </div>
            </li>`;
            });

            basketListEl.innerHTML = basketListHtml ?
                basketListHtml :
                `<li class="basket__item">Sepetinizde ürün yok.</li>`;
            totalPriceEl.innerHTML =
                totalPrice > 0 ? "Total : " + totalPrice.toFixed(2) + "₺" : null;
        };

        const addBookToBasket = (bookId) => {
            let findedBook = bookList.find((book) => book.id == bookId);
            if (findedBook) {
                const basketAlreadyIndex = basketList.findIndex(
                    (basket) => basket.product.id == bookId
                );
                if (basketAlreadyIndex == -1) {
                    let addedItem = {
                        quantity: 1,
                        product: findedBook
                    };
                    basketList.push(addedItem);
                } else {
                    if (
                        basketList[basketAlreadyIndex].quantity <
                        basketList[basketAlreadyIndex].product.stock
                    )
                        basketList[basketAlreadyIndex].quantity += 1;
                    else {
                        toastr.error("üzgünüm stoklarda kalmadı");
                        return;
                    }
                }
                listBasketItems();
                toastr.success("Kitap başarıyla sepetinize eklendi");
            }
        };

        const removeItemToBasket = (bookId) => {
            const findedIndex = basketList.findIndex(
                (basket) => basket.product.id == bookId
            );
            if (findedIndex != -1) {
                basketList.splice(findedIndex, 1);
            }
            listBasketItems();
        };

        const decreaseItemToBasket = (bookId) => {
            const findedIndex = basketList.findIndex(
                (basket) => basket.product.id == bookId
            );
            if (findedIndex != -1) {
                if (basketList[findedIndex].quantity != 1)
                    basketList[findedIndex].quantity -= 1;
                else removeItemToBasket(bookId);
                listBasketItems();
            }
        };

        const increaseItemToBasket = (bookId) => {
            const findedIndex = basketList.findIndex(
                (basket) => basket.product.id == bookId
            );
            if (findedIndex != -1) {
                if (
                    basketList[findedIndex].quantity < basketList[findedIndex].product.stock
                )
                    basketList[findedIndex].quantity += 1;
                else toastr.error("Sorry, we don't have enough stock.");
                listBasketItems();
            }
        };

        if (localStorage.getItem("basketList")) {
            basketList = JSON.parse(localStorage.getItem("basketList"));
            listBasketItems();
        }

        setTimeout(() => {
            createBookItemsHtml();
            createBookTypesHtml();
        }, 100);
    </script>



</body>

</html>
