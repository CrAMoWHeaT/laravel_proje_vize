@extends('app.adminlayout')

@section('content2')
    <h1>Giriş Yap</h1>

    <form method="POST" action="#">
        @csrf

        <label for="email">E-posta:</label>
        <input type="email" name="email" required>

        <label for="password">Şifre:</label>
        <input type="password" name="password" required>

        <button type="submit">Giriş Yap</button>
    </form>
@endsection
